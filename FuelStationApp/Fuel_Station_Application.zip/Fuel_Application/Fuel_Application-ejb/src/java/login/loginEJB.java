/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/StatelessEjbClass.java to edit this template
 */
package login;

import com.mysql.cj.x.protobuf.MysqlxPrepare.Prepare;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;

/**
 *
 * @author ImeshKarunarathne
 */
@Stateless
@LocalBean
public class loginEJB {

    public String checkUserDB(String username, String password) throws ClassNotFoundException {
        String result="";
        String SQL_QUERY="SELECT 1 FROM userregistration WHERE Mobile=? and Password=?";
        Class.forName("com.mysql.cj.jdbc.Driver");
        try (Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/fuelstationdb?useSSL=false","root","Root@123");
            PreparedStatement ps = con.prepareStatement(SQL_QUERY)){

            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            
            if(rs.next()){
                result ="1";
            }else
                result ="0";
                    
        } catch (SQLException ex) {
            Logger.getLogger(loginEJB.class.getName()).log(Level.SEVERE, null, ex);
        }
        return result;
        
    }
}
