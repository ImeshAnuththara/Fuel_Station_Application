/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/StatelessEjbClass.java to edit this template
 */
package login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;

/**
 *
 * @author ImeshKarunarathne
 */
@Stateless
@LocalBean
public class registerEJB {
    private String Username;
    private String NIC;
    private String Mobile;
    private String password;
    
    public String getUsername() {
        return Username;
    }

    public void setUsername(String Username) {
        this.Username = Username;
    }

    public String getNIC() {
        return NIC;
    }

    public void setNIC(String NIC) {
        this.NIC = NIC;
    }

    public String getMobile() {
        return Mobile;
    }

    public void setMobile(String Mobile) {
        this.Mobile = Mobile;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    

    public int UserRegistration(registerEJB reg) throws ClassNotFoundException {

        String SQL_QUERY="INSERT INTO userregistration(username,NIC,Mobile,Password) VALUES (?,?,?,?)";
        int result=0;
        Class.forName("com.mysql.cj.jdbc.Driver");
        try (Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/fuelstationdb?useSSL=false","root","Root@123");
            PreparedStatement ps = con.prepareStatement(SQL_QUERY)){
            ps.setString(1, reg.getUsername());
            ps.setString(2, reg.getNIC());
            ps.setString(3, reg.getMobile());
            ps.setString(4, reg.getPassword());
                    
            result=ps.executeUpdate();
        } catch (SQLException ex) { 
            Logger.getLogger(registerEJB.class.getName()).log(Level.SEVERE, null, ex);
        }
        return result;
    }
    
}
