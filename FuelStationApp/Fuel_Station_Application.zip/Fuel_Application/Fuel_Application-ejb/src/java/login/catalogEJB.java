/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/StatelessEjbClass.java to edit this template
 */
package login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;

/**
 *
 * @author ImeshKarunarathne
 */
@Stateless
@LocalBean
public class catalogEJB {
    private String type;
    private String quantity;
    private String phone;
    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
    

public int Order(catalogEJB reg) throws ClassNotFoundException {

        String SQL_QUERY="INSERT INTO fuelorder(Mobile,FuelType,Quantity) VALUES (?,?,?)";
        int result=0;
        Class.forName("com.mysql.cj.jdbc.Driver");
        try (Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/fuelstationdb?useSSL=false","root","Root@123");
            PreparedStatement ps = con.prepareStatement(SQL_QUERY)){
            ps.setString(1, reg.getPhone());
            ps.setString(2, reg.getType());
            ps.setString(3, reg.getQuantity());
                    
            result=ps.executeUpdate();
        } catch (SQLException ex) { 
            Logger.getLogger(catalogEJB.class.getName()).log(Level.SEVERE, null, ex);
        }
        return result;
    }
    
}
