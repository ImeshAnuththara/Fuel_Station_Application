/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package login;

import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ImeshKarunarathne
 */
public class catalogServlet extends HttpServlet {
    @EJB
    private catalogEJB catalogejb;

    String phone,quantity,type;
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        type = request.getParameter("fuel");
        quantity = request.getParameter("quantity");
        phone = request.getParameter("phone");
        
        catalogEJB reg = new catalogEJB();
        reg.setPhone(phone);
        reg.setType(type);
        reg.setQuantity(quantity);
        try {
            catalogejb.Order(reg);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(catalogServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        request.setAttribute("phone",phone);
        request.getRequestDispatcher("/Request.jsp").forward(request, response);        
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
