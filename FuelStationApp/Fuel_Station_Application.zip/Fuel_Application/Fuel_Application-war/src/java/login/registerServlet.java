/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package login;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ImeshKarunarathne
 */
public class registerServlet extends HttpServlet {

    @EJB
    private registerEJB registerejb;
    String username,password,result;
    String NIC,Mobile;
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        username = request.getParameter("username");
        NIC = request.getParameter("nic");
        Mobile = request.getParameter("phone");
        password = request.getParameter("password");

        registerEJB reg = new registerEJB();
        reg.setUsername(username);
        reg.setNIC(NIC);
        reg.setMobile(Mobile);
        reg.setPassword(password);
        PrintWriter out = response.getWriter();
        
        try {
            registerejb.UserRegistration(reg);
            request.getRequestDispatcher("/index.jsp").forward(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(registerServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
