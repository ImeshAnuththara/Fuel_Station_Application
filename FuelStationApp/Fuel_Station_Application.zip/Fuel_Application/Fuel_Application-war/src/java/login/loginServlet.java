/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package login;

import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ImeshKarunarathne
 */
public class loginServlet extends HttpServlet {

    @EJB
    private loginEJB loginEJB;
    String username,password,result;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            username = request.getParameter("phone");
            password = request.getParameter("password");
            result = loginEJB.checkUserDB(username, password);
            int value =Integer.parseInt(result);
            if(result.equals("1")){
            request.setAttribute("phone",username);
            request.getRequestDispatcher("/catlog.jsp").forward(request, response);
            }
            else{
            //out.println(result);
            request.getRequestDispatcher("/index.jsp").forward(request, response);
            }
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(loginServlet.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            out.close();
        }        

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
